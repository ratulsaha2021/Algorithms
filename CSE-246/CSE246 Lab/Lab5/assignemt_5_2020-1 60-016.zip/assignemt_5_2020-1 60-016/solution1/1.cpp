#include <bits/stdc++.h>
using namespace std;

int main() {
    while (1) {
        int T,i,sum=0;
        cin >> T;
        long int a[T],j,k;

        for(i=0; i<T; i++) {
            cin >> a[i];
        }

        cout << endl;

        for(i=0; i<T; i++) {
            sum=0;
            for(j=2; j<=a[i]; j++){
                if(a[i]%j==0){
                    sum++;
                }
            }
            if(sum==1) {
                cout << "PRIME";
                cout << endl;
            }
            else {
                cout << "NOT PRIME";
                cout << endl;
            }
        }

        cout << endl;
    }
}
